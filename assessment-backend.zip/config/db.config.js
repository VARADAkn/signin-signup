module.exports = {
  HOST: "localhost",
  USER: "postgres",
  PASSWORD: "Varada@2003",
  DB: "assessmentdb",
  dialect: "postgres"
};